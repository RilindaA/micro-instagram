import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ListPhotosRoutingModule } from './list-photos-routing.module';
import { ListPhotosComponent } from './list-photos.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [ListPhotosComponent],
  imports: [
    CommonModule,
    ListPhotosRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class ListPhotosModule { }
