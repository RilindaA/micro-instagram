import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject, forkJoin, fromEvent, Observable, throwError } from 'rxjs';
import { catchError, map, take } from "rxjs/operators";
import { Photo } from '../interfaces/photo';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-list-photos',
  templateUrl: './list-photos.component.html',
  styleUrls: ['./list-photos.component.scss']
})
export class ListPhotosComponent implements OnInit {
  photos: BehaviorSubject<Photo[]> = new BehaviorSubject<Photo[]>([]);
  items$: Observable<any> = this.photos.asObservable();
  currentPage: number = 0;
  pageSize: number = 9;
  addMode: boolean = false;
  url: any;
  photoFG = new FormGroup({
    image: new FormControl('', Validators.required),
    title: new FormControl('', Validators.required)
  });
  constructor(private service: DataService,
              private router: Router,
              private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getPhotos();
  }

  getPhotos(){
    this.service.getPhotos(this.currentPage, this.pageSize).subscribe((data: any) => {
      this.photos.next(data);
      const content = document.querySelector('.list-photos');
      const scroll$ = fromEvent(content!, 'scroll').pipe(map(() => { return content!.scrollTop; }));

      scroll$.subscribe((scrollPos) => {
        let limit = content!.scrollHeight - content!.clientHeight;
        if (Math.round(scrollPos) === limit) {
          this.currentPage += this.pageSize;
          forkJoin([this.items$.pipe(take(1)), this.service.getPhotos(this.currentPage, this.pageSize)]).subscribe((data: Array<Array<Photo>>) => {
            const newArr = [...data[0], ...data[1]];
            this.photos.next(newArr);
          });
        }
      });
    })
  }
  goToDetails(id){
    this.router.navigateByUrl('/photo-details/' + id);
  }
  scrollToTop(){
    const content = document.querySelector('.list-photos');
    content.scrollTo(0, 0);
  }
  addPhoto(){
    this.addMode = true;
  }
  uploadFile(e){
    let reader = new FileReader();
    let file = e.target.files[0];
    if (e.target.files && e.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.url = reader.result;
      }       
    }
  }
  savePhoto(){
    const { image, title } = this.photoFG.value;
    const dataObj: Photo = {
      id: Math.random() * 100,
      title: title,
      url: image
    }
    this.service.addPhoto(dataObj).pipe(catchError((err: any) => {
      this.toastr.error(err.name);
      return throwError(err);
    })).subscribe(data => {
      console.log(data);
      
      this.toastr.success('Photo added successfully!');
      this.addMode = false;
    });
  }
  cancel(){
    this.addMode = false;
  }

}
