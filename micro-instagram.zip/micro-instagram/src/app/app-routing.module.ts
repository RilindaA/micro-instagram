import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PhotoDetailsModule } from './photo-details/photo-details.module';

const routes: Routes = [
  { path: '', loadChildren: () => import('./list-photos/list-photos.module').then(p => p.ListPhotosModule) },
  { path: '', loadChildren: () => import('./photo-details/photo-details.module').then(p => p.PhotoDetailsModule) },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    PhotoDetailsModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
