import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Photo } from '../interfaces/photo';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private url = "https://jsonplaceholder.typicode.com/photos";
  constructor(private http: HttpClient) { }

  public getPhotos(pageNumber: number, pageSize: number) {
    return this.http.get(`${this.url}?_start=${pageNumber}&_limit=${pageSize}`);
  }

  public getPhoto(id: number){
    return this.http.get(`${this.url}/${id}`);
  }

  public addPhoto(obj){
    return this.http.post(`${this.url}`,obj)
  }

  public deletePhoto(id){
    return this.http.delete(`${this.url}/${id}`);
  }

  public updatePhoto(dataObj: Photo, id){
    return this.http.put(`${this.url}/${id}`,dataObj);
  }
}
