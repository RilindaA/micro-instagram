import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import { ToastrModule } from 'ngx-toastr';


@NgModule({
  declarations: [ConfirmDialogComponent],
  imports: [
    CommonModule,
    BrowserAnimationsModule, 
    MatDialogModule,
    ToastrModule.forRoot({
      closeButton: true,
      timeOut: 1500,
      progressBar: true,
    })
  ],
  exports: [
    ConfirmDialogComponent
  ]
})
export class SharedModule { }
