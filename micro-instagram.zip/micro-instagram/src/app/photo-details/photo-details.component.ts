import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Photo } from '../interfaces/photo';
import { DataService } from '../services/data.service';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-photo-details',
  templateUrl: './photo-details.component.html',
  styleUrls: ['./photo-details.component.scss']
})
export class PhotoDetailsComponent implements OnInit {
  editMode: boolean = false;
  photoId: number;
  title: string;
  url:any;
  file:File;
  photoFG = new FormGroup({
    image: new FormControl(''),
    title: new FormControl('')
  });
  constructor(private service: DataService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.photoId = +this.activatedRoute.snapshot.paramMap.get('id');
    this.getPhoto();
  }
  getPhoto(){
    this.service.getPhoto(this.photoId).subscribe((res:any) => {
      this.title = res.title;
      this.url = res.url;
    });
  }
  goToEdit(){
    this.editMode = true;
    this.photoFG.get('title').setValue(this.title);
  }
  uploadFile(e){
    let reader = new FileReader();
    let file = e.target.files[0];
    if (e.target.files && e.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.url = reader.result;
      }       
    }
  }
  updatePhoto(){
    const { image, title } = this.photoFG.value;
    const dataObj: Photo = {
      id: this.photoId,
      title: title,
      url: image ? image : this.url
    }
    this.service.updatePhoto(dataObj, this.photoId).pipe(catchError((err: any) => {
      this.toastr.error(err.name);
      return throwError(err);
    })).subscribe(data => {
      this.toastr.success('Photo updated successfully!');
      this.router.navigateByUrl('');
    });
  }
  
  deletePhoto(){
    const confirmDialog = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Remove photo',
        message: 'Are you sure, you want to remove this photo?'
      }
    });
    confirmDialog.afterClosed().pipe(catchError((err: any) => {
      this.toastr.error(err);
      return throwError(err);
    })).subscribe(result => {
      if (result === true) {
        this.service.deletePhoto(this.photoId);
        this.toastr.success('Photo deleted successfully!');
        this.router.navigateByUrl('');
      }  
    });
  }
  cancel(){
    this.editMode = false;
  }

}
