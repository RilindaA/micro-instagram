import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PhotoDetailsRoutingModule } from './photo-details-routing.module';
import { PhotoDetailsComponent } from './photo-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [PhotoDetailsComponent],
  imports: [
    CommonModule,
    PhotoDetailsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ]
})
export class PhotoDetailsModule { }
